package com.example.aispl_assignment;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

public class SwipeToDeleteCallback extends ItemTouchHelper.SimpleCallback {

    private final Drawable icon;
    private final ColorDrawable background;
    private final Paint clearPaint = new Paint();

    public SwipeToDeleteCallback(Context context) {
        super(0, ItemTouchHelper.LEFT);
        icon = ContextCompat.getDrawable(context, R.drawable.ic_baseline_delete_24);
        background = new ColorDrawable(Color.parseColor("#F44336"));
        clearPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
    }

    @Override
    public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
        return false;
    }

    @Override
    public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {

    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onChildDraw(@NonNull Canvas canvas, @NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, float dX, float dY, int actionState, boolean isCurrentlyActive) {
        View itemView = viewHolder.itemView;
        int itemHeight = itemView.getBottom() - itemView.getTop();
        boolean isCanceled = dX == 0.0f && !isCurrentlyActive;

        if (isCanceled) {
            clearCanvas(canvas, itemView.getRight() + dX, (float) itemView.getTop(), (float) itemView.getRight(), (float) itemView.getBottom());
            super.onChildDraw(canvas, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);
            return;
        }

        // Draw the red delete background
        background.setBounds(
                itemView.getRight() + ((int) dX),
                itemView.getTop(),
                itemView.getRight(),
                itemView.getBottom()
        );
        background.draw(canvas);

        // Calculate position of delete icon
        icon.setTint(Color.parseColor("#FFFFFF"));
        int iconTop = itemView.getTop() + (itemHeight - icon.getIntrinsicHeight()) / 2;
        int iconMargin = (itemHeight - icon.getIntrinsicHeight()) / 2;
        int iconLeft = itemView.getRight() - iconMargin - icon.getIntrinsicWidth();
        int iconRight = itemView.getRight() - iconMargin;
        int iconBottom = iconTop + icon.getIntrinsicHeight();

        // Draw the delete icon
        icon.setBounds(iconLeft, iconTop, iconRight, iconBottom);
        icon.draw(canvas);

        super.onChildDraw(canvas, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);
    }

    private void clearCanvas(Canvas canvas, float left, float top, float right, float bottom) {
        if (canvas != null) {
            canvas.drawRect(left, top, right, bottom, clearPaint);
        }
    }
}
