package com.example.aispl_assignment;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class AdapterClass extends RecyclerView.Adapter<AdapterClass.MyviewHolder> {
    private Context mContext;
    private List<Episode>modelClassList;

    public AdapterClass(Context mContext, List<Episode> modelClassList) {
        this.mContext = mContext;
        this.modelClassList = modelClassList;
    }

    @NonNull
    @Override
    public AdapterClass.MyviewHolder onCreateViewHolder(@NonNull  ViewGroup parent, int viewType) {
        View view ;
        LayoutInflater mInflater = LayoutInflater.from(mContext);
        view = mInflater.inflate(R.layout.girls_layout,parent,false);
        return new MyviewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull  AdapterClass.MyviewHolder holder, int position) {
//        ModelClass modelClass = modelClassList.get(position);
        Episode episode = modelClassList.get(position);

        holder.txtName.setText(episode.getName());
        holder.txtseason.setText(episode.getSeason()+ "");
        holder.txtnumber.setText(episode.getNumber() + "");
        holder.txttype.setText(episode.getType());
        holder.txtsummary.setText(episode.getSummary());

        Glide.with(mContext).load(episode.getImage().getMedium()).into(holder.imgview);
    }

    @Override
    public int getItemCount() {
        return modelClassList.size();
    }

    public class MyviewHolder extends RecyclerView.ViewHolder {
        TextView txtName,txtseason,txtnumber,txttype,txtsummary;
        ImageView imgview;
        public MyviewHolder(@NonNull  View itemView) {
            super(itemView);
            txtName=itemView.findViewById(R.id.product_name);
            txtseason=itemView.findViewById(R.id.seasonid);
            txtnumber=itemView.findViewById(R.id.numberid);
            txttype=itemView.findViewById(R.id.idtype);
            txtsummary=itemView.findViewById(R.id.idsummary);
            imgview=itemView.findViewById(R.id.season_img);
        }
    }
}
