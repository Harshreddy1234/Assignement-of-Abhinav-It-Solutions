package com.example.aispl_assignment;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    TextView txtName, txtType, txtLanguage, txtSummary;
    ImageView imgview;
    List<ModelClass> ordersList;
    List<Episode> episodeList;

    RecyclerView recyclerView;
    AdapterClass myAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        txtName = findViewById(R.id.name);
        txtType = findViewById(R.id.type);
        txtLanguage = findViewById(R.id.language);
        txtSummary = findViewById(R.id.summary);
        imgview = findViewById(R.id.girlsepisodes);

        recyclerView = findViewById(R.id.recycleview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        episodeList = new ArrayList<>();
        ordersList = new ArrayList<>();

        getShowsGirls();

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(new SwipeToDeleteCallback(this) {
            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getAdapterPosition();

                episodeList.remove(position);
                myAdapter.notifyItemRemoved(position);

            }
        });

        itemTouchHelper.attachToRecyclerView(recyclerView);
    }

    private void getShowsGirls() {

        String request_url = "https://api.tvmaze.com/singlesearch/shows?q=girls&embed=episodes";
        Log.d("URL", "URL >>>>" + request_url);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, request_url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        Log.d("Response", "Response >>>" + response);
//                      System.out.println(response);
                        try {
                            JSONObject jsonObject = new JSONObject(String.valueOf(response));
                            int id = jsonObject.getInt("id");
                            String url = jsonObject.getString("url");
                            String name = jsonObject.getString("name");
                            String type = jsonObject.getString("type");
                            String language = jsonObject.getString("language");
                            String summary = jsonObject.getString("summary");
                            JSONObject tutorialsArray = jsonObject.getJSONObject("image");
                            String medium = tutorialsArray.getString("medium");
                            String original = tutorialsArray.getString("original");
                            JSONObject embeddedlist = jsonObject.getJSONObject("_embedded");
                            JSONArray jsonArray = embeddedlist.getJSONArray("episodes");

                            for (int p = 0; p < jsonArray.length(); p++) {
                                JSONObject episode = jsonArray.getJSONObject(p);
                                JSONObject imgObj = episode.getJSONObject("image");

                                Episode model = new Episode(
                                        episode.getInt("id"),
                                        episode.getString("name"),
                                        episode.getInt("season"),
                                        episode.getInt("number"),
                                        episode.getString("type"),
                                        new Image(
                                                imgObj.getString("medium"),
                                                imgObj.getString("original")
                                        ),
                                        episode.getString("summary")
                                );

                                episodeList.add(model);
                            }

                            Embedded embedded = new Embedded(episodeList);
                            ModelClass modelClass = new ModelClass(id, name, type,
                                    new Image(medium, original), summary, embedded);
                            ordersList.add(modelClass);
                            myAdapter = new AdapterClass(getApplicationContext(), episodeList);
                            recyclerView.setAdapter(myAdapter);


                            Log.d("TAG", "onResponse: id:" + id);
                            Log.d("TAG", "onResponse: url:" + url);
                            Log.d("TAG", "onResponse: name:" + name);
                            Log.d("TAG", "onResponse: type:" + type);
                            Log.d("TAG", "onResponse: language:" + language);
                            Log.d("TAG", "onResponse: summary:" + summary);
                            Log.d("TAG", "onResponse: tutorialsArray:" + tutorialsArray.toString());
                            Log.d("TAG", "onResponse: medium:" + medium);
                            Log.d("TAG", "onResponse: original:" + original);
                            txtName.setText(name);
                            txtType.setText(type);
                            txtLanguage.setText(language);
                            txtSummary.setText(summary);
                            Glide.with(getApplicationContext()).load(original).into(imgview);


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {


                    }
                });
        //Creating a request queue
        Volley.newRequestQueue(getApplicationContext()).add(jsonObjectRequest);
    }

}